# Round 2 stochastic Heston parameter point

This isolated execution changes only initial variance to v0=1/25. Parameters
(kappa,vbar,xi,rho,v0)=(3,9/200,23/100,-11/20,1/25); S0=100, r=1/100,
h=1/768, twelve fixings at m/12, and payoff (A-95)+-(A-110)+. Bias is Q-P.
The raw positive-part Euler scheme and continuous Heston model are retained.
The original exp(.78) moment envelope is conservative at this point because
the same growth bound gives exp(.6+4v0)=exp(.76). All v0-dependent transforms,
prefixes, integrated-variance floors and infinite tails are recomputed.
The preflight does not certify a price. A complete pointwise enclosure requires
all principal and independent jobs and their finite node/fee checks to finish.
This execution makes no claim about a larger parameter region, posterior,
stochastic-Heston first-order expansion or signed Asian leading coefficient.
