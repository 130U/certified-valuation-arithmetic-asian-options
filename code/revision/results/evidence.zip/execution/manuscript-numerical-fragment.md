The frozen original calculation was re-executed under Windows x86-64 CPython
3.12.14 with python-flint 0.8.0. The Asian and posterior modules, including their
independent implementations, completed all ten jobs; every mathematical payload
agreed exactly with the established reference (hashes and measured times are
metadata). The independent Asian remainder calculation uses a hyperbolic matrix
Riccati flow, an ordered-pair profile catalogue and a separately indexed reverse
Euler grid. The independent linear calculation uses complex Euler recursion and
exponential matrix blocks. These constructions strengthen implementation checks,
but share Arb and the analytical bounds and therefore do not independently
exclude errors in those bounds.

The nonlinear part can be optimized without changing the price certificate's
scope. We computed the positive Laplace moments
\(d=\sum_{\nu=P,Q}E_\nu[G^2I_1^{-1/2}]\) and
\(e=\sum_{\nu=P,Q}E_\nu[(A-G)GI_1^{-1/2}]\), using \(A\geq G\) to preserve
the cancellation in the second quantity. Thus \(c_*=1+e/d\). At \(h=1/768\),
outward Darboux sums, their integral tails and the original-kernel projection
fees give \(c_*\in[1.003427394603466100946724,
1.003669831096000915452372]\). Both the 256-bit principal calculation and a
384-bit matrix-flow calculation enclose the same moments. The rational midpoint
choice \(c=1.0035486\) is an approximation to the optimizer, rather than an
assertion that the exact optimizer has been evaluated. It slightly increases the
computed nonlinear upper width relative to the retained \(c=1.0035464\), which
is already near the optimum. These comparisons concern only the nonlinear
contribution; neither the true nonlinear objective nor the complete certificate
is optimized by choosing the midpoint of an optimizer enclosure.

| Common c | Nonlinear contribution to signed-bias interval width, h=1/768 |
|---|---:|
| 1 | 0.040551110716116841 |
| 1.0035464 | 0.020478587751323761 |
| 1.0035486 | 0.020478592979195334 |

The posterior mesh comparison retains the same small-positive-xi prior,
likelihood covariance, exact binary64 synthetic observations and target
Lipschitz bound. All cells on the added meshes were checked by the 384-bit
independent erfc/integer-quadratic/advancing-pointer construction. Refinement
reduces the all-probability-level Asian-price quantile-displacement enclosure,
while the nuisance perturbation and same-parameter scheme fees remain fixed:

| Cells | One observation bound | Nine observation bound | Coupling steps (one/nine) |
|---:|---:|---:|---:|
| 4096 | 0.008018821657241945 | 0.012716404216982817 | 2 / 5 |
| 8192 | 0.006452960803994987 | 0.010367612937112381 | 2 / 7 |
| 16384 | 0.006061495590683248 | 0.009584682510488902 | 3 / 12 |

The larger nine-observation enclosure measures conservatism in the envelope and
transport bounds; it does not establish a larger true numerical bias. The saved
posterior CDF envelopes and 0.025, 0.5 and 0.975 quantile brackets concern the
\(v_0\) marginal. They provide an uncertainty-scale diagnostic but do not
evaluate absolute posterior Asian-price quantiles.

At four deterministic-variance points, direct evaluation of the Gaussian score
norm gives the following rigorous, deliberately broad signed coefficient
enclosures. The last column is an analytical bound on
\(|e_h-h\beta_{\rm Asian}|\) at \(h=1/768\), not a computed residual:

| v0 | beta Asian enclosure (outward) | h=1/768 residual upper bound |
|---:|---:|---:|
| 0.03 | [-3.441491357547553177, 3.441491357547553177] | 0.000121667772167665 |
| 0.04 | [-0.928189504541648078, 0.928189504541648078] | 0.000036646883471913 |
| 0.05 | [-0.785853081399917462, 0.785853081399917462] | 0.000034532368482741 |
| 0.06 | [-2.057270821363254260, 2.057270821363254260] | 0.000099684584982201 |

Each enclosure contains zero. A numerical evaluation of the signed twelve-
dimensional Asian leading-coefficient integral, a nonzero coefficient conclusion
and an empirical second-order residual experiment remain open. The new score
norm evaluations are reported as a partial response to the requested coefficient
experiment and do not complete that application.
